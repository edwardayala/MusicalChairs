# cutout_characters
Repository for cutout animation characters setup in Godot Engine
